<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Cart_items extends Model
{
    protected $table='cart_items';
}
